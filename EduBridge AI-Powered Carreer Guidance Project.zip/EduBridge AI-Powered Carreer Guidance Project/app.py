

from flask import Flask, render_template, request, redirect, url_for, session
from pymongo import MongoClient
import bcrypt
import smtplib
from email.mime.text import MIMEText
import random

app = Flask(__name__)
app.secret_key = "secretkey"

client = MongoClient("mongodb://localhost:27017/")
db = client.carreer_guidance
users = db.datas

@app.route("/")
def index():
    return redirect(url_for("login")) 

@app.route("/home")
def home():
    if "email" in session:
        return render_template("home.html")  
    return "You are not logged in. <a href='/login'>Login</a>"

@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        email = request.form["email"]
        password = request.form["password"]

        if users.find_one({"email": email}):
            return render_template("errors/alreadyexist.html") 

        verification_code = random.randint(10000, 99999)
        send_verification_email(email, verification_code)

        session['verification_code'] = verification_code
        session['pending_user'] = {"email": email, "password": password} 
        return render_template("emailverification.html")

    return render_template("register.html")

@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        email = request.form["email"]
        password = request.form["password"]


        user = users.find_one({"email": email})
        
        if user is None:
            return render_template("errors/nouserexist.html") 

        if bcrypt.checkpw(password.encode("utf-8"), user["password"]):
            session["email"] = email
            return redirect(url_for("home"))  
        
        return "Invalid email or password!" 
    
    return render_template("login.html")  

@app.route("/logout", methods=["GET", "POST"])
def logout():
    session.pop("email", None)
    return render_template ("login.html")
    

def send_verification_email(email, code):
    msg = MIMEText(f"Your verification code is: {code}")
    msg['Subject'] = 'Email Verification'
    msg['From'] = 'your_email@example.com'
    msg['To'] = email

    
    with smtplib.SMTP('smtp.gmail.com', 587) as server:
        server.starttls()
        server.login('projectxkgcas@gmail.com', 'xfgh skco lnro fxpz')
        server.send_message(msg)

verification_code = random.randint(10000, 99999)  

@app.route("/verify", methods=["POST"])
def verify():
    code = request.form["code"]
    if code == str(session.get('verification_code')):
        user_data = session.pop('pending_user', None)  
        if user_data:
            hashed_password = bcrypt.hashpw(user_data["password"].encode("utf-8"), bcrypt.gensalt())
            users.insert_one({"email": user_data["email"], "password": hashed_password})
            return render_template("verification_success.html") 
    else:
        return "Invalid verification code. Please try again."
    

if __name__ == "__main__":
    app.run(debug=True)
